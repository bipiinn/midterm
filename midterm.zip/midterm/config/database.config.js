module.exports = {
    url :'mongodb+srv://bipindon:UY4KUi6tLQf9iEH8@cluster0.ju3yfnp.mongodb.net/'
}